This readme file describes the content of the archive file "nRF905-DF.zip"

Folder "Loop_35x20mm_433MHz_nRF9x5" contains the gerber files for a layout of a 35x20mm Loop Antenna for 433MHz
Folder "PCB_nRF905_diff_0603_2-0" contains the gerber files of the recommended layout for a differential antenna connection to the nRF905.
Folder "PCB_nRF905_single_netw_0603_433_2-0" contains the gerber files of the recommended layout for a single ended 433MHz antenna network to the nRF905.
Folder "PCB_nRF905_single_netw_868-915_0603_2-0" contains the gerber files of the recommended layout for a single ended 868/915MHz antenna network to the nRF905.